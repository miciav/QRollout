 #!/bin/bash

echo "this scrip enable some mimelnk icons for nuvox icons theme"
cp -R mimelnk ~/.kde/share/
echo "ok"
echo 'installed for the user:' $USER
echo 